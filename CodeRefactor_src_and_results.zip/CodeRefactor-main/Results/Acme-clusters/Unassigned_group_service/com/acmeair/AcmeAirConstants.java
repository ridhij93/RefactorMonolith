package com.acmeair;

public interface AcmeAirConstants {
}
